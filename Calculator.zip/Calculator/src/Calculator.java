import java.util.Scanner;
public class Calculator {
    public static void main(String[] args) {

        String[] array1 = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        String[] array2 = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        Error error1 = new Error();
        IfElse ifelse1 = new IfElse();
        for (int i = 0; i >= 0; i++) {
            System.out.println("Input: ");
            Scanner s = new Scanner(System.in);
            String string = s.nextLine();
            String str[] = string.split("[+*/-]");
            ifelse1.stringIfElse = string;
            if (str.length == 2) {
                str[0] = str[0].trim();
                str[1] = str[1].trim();
                boolean f = false;
                boolean t = false;
                for (int j = 0; j < array2.length; j++) {

                    if (str[0].equals(array2[j])) {
                        f = true;
                        break;
                    }
                }
                for (int j = 0; j <= 9; j++) {
                    if (str[1].equals(array2[j])) {
                        t = true;
                        break;
                    }


                }
                if (f == true && t == true) {
                    Converter c1 = new Converter();
                    c1.number = str[0];
                    c1.convert1();
                    Converter c2 = new Converter();
                    c2.number = str[1];
                    c2.convert1();

                    ifelse1.a = Integer.parseInt(c1.number);
                    ifelse1.b = Integer.parseInt(c2.number);
                    ifelse1.ifElse();
                    ifelse1.switch1();
                    if (ifelse1.y > 0) {
                        String str1 = String.valueOf(ifelse1.y);
                        Converter c3 = new Converter();
                        c3.number1 = str1;
                        c3.convert2();
                        System.out.println("Output:");
                        System.out.println(c3.number1);
                    } else {
                        System.out.println("When introducing Roman numbers, a must be greater than b");
                        break;
                    }
                } else {
                    f = false;t = false;

                    for (int j = 0; j < array1.length; j++) {

                        if (str[0].equals(array1[j])) {
                            f = true;
                            break;
                        }

                    }
                    for (int j = 0; j < array1.length; j++) {

                        if (str[1].equals(array1[j])) {
                            t = true;
                            break;
                        }

                    }

                    if (f == true && t == true) {
                        ifelse1.a = Integer.parseInt(str[0]);
                        ifelse1.b = Integer.parseInt(str[1]);
                        ifelse1.ifElse();
                        ifelse1.switch1();
                        System.out.println("Output:");
                        System.out.println(ifelse1.y);
                    } else {
                        error1.error();
                        break;
                    }

                }
            } else {
                error1.error();
                break;
            }


        }


    }

}

