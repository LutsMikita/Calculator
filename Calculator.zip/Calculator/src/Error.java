public class Error {
    public void error() {System.out.println("You can enter only Arabic or Roman numbers up to and including 10");
            System.out.println("perform operations a+b, a-b, a*b, a/b.");}
}
