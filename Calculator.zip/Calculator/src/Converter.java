public class Converter {
    String number= new String();
    String number1 = new String();
    Error error1 = new Error();
    public void convert1(){


        switch(number){
            case "I": number = "1";break;
            case "II": number = "2";break;
            case "III": number = "3";break;
            case "IV": number = "4";break;
            case "V": number = "5";break;
            case "VI": number = "6";break;
            case "VII": number = "7";break;
            case "VIII": number = "8";break;
            case "IX": number = "9";break;
            case "X": number = "10";break;
            default: error1.error();break;
        }
    }
    public void convert2(){

        switch(number1){
            case "1": number1 = "I";break;
            case "2": number1 = "II";break;
            case "3": number1 = "III";break;
            case "4": number1 = "IV";break;
            case "5": number1 = "V";break;
            case "6": number1 = "VI";break;
            case "7": number1 = "VII";break;
            case "8": number1 = "VIII";break;
            case "9": number1 = "IX";break;
            case "10": number1 = "X";break;
            case "11": number1 = "XI";break;
            case "12": number1 = "XII";break;
            case "13": number1 = "XIII";break;
            case "14": number1 = "XIV";break;
            case "15": number1 = "XV";break;
            case "16": number1 = "XVI";break;
            case "17": number1 = "XVII";break;
            case "18": number1 = "XVIII";break;
            case "19": number1 = "XIX";break;
            case "20": number1 = "XX";break;
            case "21": number1 = "XXI";break;
            case "22": number1 = "XXII";break;
            case "23": number1 = "XXIII";break;
            case "24": number1 = "XXIV";break;
            case "25": number1 = "XXV";break;
            case "26": number1 = "XXI";break;
            case "27": number1 = "XXVII";break;
            case "28": number1 = "XXVIII";break;
            case "29": number1 = "XXIX";break;
            case "30": number1 = "XXX";break;
            case "31": number1 = "XXXI";break;
            case "32": number1 = "XXXII";break;
            case "33": number1 = "XXXIII";break;
            case "34": number1 = "XXXIV";break;
            case "35": number1 = "XXXV";break;
            case "36": number1 = "XXXVI";break;
            case "37": number1 = "XXXVII";break;
            case "38": number1 = "XXXVIII";break;
            case "39": number1 = "XXXIX";break;
            case "40": number1 = "XL";break;
            case "41": number1 = "XLI";break;
            case "42": number1 = "XLII";break;
            case "43": number1 = "XLIII";break;
            case "44": number1 = "XLIV";break;
            case "45": number1 = "XLV";break;
            case "46": number1 = "XLVI";break;
            case "47": number1 = "XLVII";break;
            case "48": number1 = "XLVIII";break;
            case "49": number1 = "XLIX";break;
            case "50": number1 = "L";break;
            case "51": number1 = "LI";break;
            case "52": number1 = "LII";break;
            case "53": number1 = "LIII";break;
            case "54": number1 = "LIV";break;
            case "55": number1 = "LV";break;
            case "56": number1 = "LVI";break;
            case "57": number1 = "LVII";break;
            case "58": number1 = "LVIII";break;
            case "59": number1 = "LIX";break;
            case "60": number1 = "LX";break;
            case "61": number1 = "LXI";break;
            case "62": number1 = "LXII";break;
            case "63": number1 = "LXIII";break;
            case "64": number1 = "LXIV";break;
            case "65": number1 = "LXV";break;
            case "66": number1 = "LXVI";break;
            case "67": number1 = "LXVII";break;
            case "68": number1 = "LXVIII";break;
            case "69": number1 = "LXIX";break;
            case "70": number1 = "LXX";break;
            case "71": number1 = "LXXI";break;
            case "72": number1 = "LXXII";break;
            case "73": number1 = "LXXIII";break;
            case "74": number1 = "LXXIV";break;
            case "75": number1 = "LXXV";break;
            case "76": number1 = "LXXVI";break;
            case "77": number1 = "LXXVII";break;
            case "78": number1 = "LXXVIII";break;
            case "79": number1 = "LXXIX";break;
            case "80": number1 = "LXXX";break;
            case "81": number1 = "LXXXI";break;
            case "82": number1 = "LXXXII";break;
            case "83": number1 = "LXXXIII";break;
            case "84": number1 = "LXXXIV";break;
            case "85": number1 = "LXXXV";break;
            case "86": number1 = "LXXXVI";break;
            case "87": number1 = "LXXXVII";break;
            case "88": number1 = "LXXXVIII";break;
            case "89": number1 = "LXXXIX";break;
            case "90": number1 = "XC";break;
            case "91": number1 = "XC";break;
            case "92": number1 = "XCII";break;
            case "93": number1 = "XCIII";break;
            case "94": number1 = "XCIV";break;
            case "95": number1 = "XCV";break;
            case "96": number1 = "XCVI";break;
            case "97": number1 = "XCVII";break;
            case "98": number1 = "XCVIII";break;
            case "99": number1 = "XCIX";break;
            case "100": number1 = "C";break;
            default: error1.error();break;
        }

    }
}
