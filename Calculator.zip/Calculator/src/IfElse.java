public class IfElse {
    byte x;
    int a, b;
    public void znak(byte x){  this.x = x;}
    int y;
    public void result(int y){  this.y = y;}
    String stringIfElse;
    Error error1 = new Error();
    public void ifElse(){
     if (stringIfElse.indexOf(43) != -1) {
        x = 1;
        } else if (stringIfElse.indexOf(45) != -1) {
        x = 2;
        } else if (stringIfElse.indexOf(42) != -1) {
        x = 3;
        } else if (stringIfElse.indexOf(47) != -1) {
        x = 4;
        } else {
        error1.error();
        }
    }
    public void switch1(){
        switch (x) {
            case 1:
                y = a + b;
                break;
            case 2:
                y = a - b;
                break;
            case 3:
                y = a * b;
                break;
            case 4:
                y = a / b;
                break;
            default:
                error1.error();
                break;
        }
    }
}
